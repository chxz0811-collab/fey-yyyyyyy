
// ==================================
// TO MY FAVORITE STAR
// Made with love for เฟย์ ♡
// ==================================


// 1. Opening screen

const welcomeScreen = document.getElementById("welcomeScreen");
const mainWebsite = document.getElementById("mainWebsite");
const startButton = document.getElementById("startButton");

startButton.addEventListener("click", () => {
    welcomeScreen.classList.add("fade-out");
    mainWebsite.classList.remove("hidden");

    setTimeout(() => {
        welcomeScreen.style.display = "none";
    }, 1000);

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});


// 2. Star background

const canvas = document.getElementById("starCanvas");
const ctx = canvas.getContext("2d");

let stars = [];

function resizeCanvas() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = window.innerWidth * ratio;
    canvas.height = window.innerHeight * ratio;

    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";

    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);

    createStars();
}

function createStars() {
    stars = [];

    const count = Math.min(
        180,
        Math.floor(window.innerWidth / 4)
    );

    for (let i = 0; i < count; i++) {
        stars.push({
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            radius: Math.random() * 1.8 + 0.3,
            opacity: Math.random(),
            speed: Math.random() * 0.02 + 0.005,
            direction: Math.random() > 0.5 ? 1 : -1
        });
    }
}

function drawStars() {
    ctx.clearRect(
        0,
        0,
        window.innerWidth,
        window.innerHeight
    );

    stars.forEach(star => {
        star.opacity += star.speed * star.direction;

        if (star.opacity >= 1 || star.opacity <= 0.15) {
            star.direction *= -1;
        }

        ctx.beginPath();

        ctx.arc(
            star.x,
            star.y,
            star.radius,
            0,
            Math.PI * 2
        );

        ctx.fillStyle =
            `rgba(255,255,255,${star.opacity})`;

        ctx.shadowBlur = 10;
        ctx.shadowColor = "#c7b5ff";

        ctx.fill();
    });

    ctx.shadowBlur = 0;

    requestAnimationFrame(drawStars);
}

window.addEventListener("resize", resizeCanvas);

resizeCanvas();
drawStars();


// 3. Anniversary counter

// 28 October 2026 at midnight (local time)

const anniversary = new Date(2026, 9, 28, 0, 0, 0);

function updateCounter() {
    const now = new Date();

    let difference = now - anniversary;

    const isFuture = difference < 0;

    if (isFuture) {
        difference = Math.abs(difference);
    }

    const days = Math.floor(
        difference / (1000 * 60 * 60 * 24)
    );

    const hours = Math.floor(
        (difference / (1000 * 60 * 60)) % 24
    );

    const minutes = Math.floor(
        (difference / (1000 * 60)) % 60
    );

    const seconds = Math.floor(
        (difference / 1000) % 60
    );

    document.getElementById("days").textContent = days;
    document.getElementById("hours").textContent = hours;
    document.getElementById("minutes").textContent = minutes;
    document.getElementById("seconds").textContent = seconds;

    document.getElementById("counterTitle").textContent =
        isFuture
            ? "Countdown to our special day"
            : "We've been together for";
}

updateCounter();
setInterval(updateCounter, 1000);


// 4. Music player

const loveAudio = document.getElementById("loveAudio");
const musicButton = document.getElementById("musicButton");

musicButton.addEventListener("click", async () => {
    if (loveAudio.paused) {
        try {
            await loveAudio.play();
            musicButton.textContent = "❚❚ Pause our song";
        } catch (error) {
            musicButton.textContent = "เล่นเพลงไม่ได้ — ตรวจสอบไฟล์เสียง";
            console.error("Music error:", error);
        }
    } else {
        loveAudio.pause();
        musicButton.textContent = "▶ Play our song";
    }
});

loveAudio.addEventListener("ended", () => {
    musicButton.textContent = "▶ Play our song";
});

loveAudio.addEventListener("error", () => {
    musicButton.textContent = "ตรวจสอบไฟล์เพลง";
});


// 5. Random love message

const loveMessages = [
    "เธอคือสิ่งที่ดีที่สุดที่เกิดขึ้นในชีวิตเรา 💗",
    "ถ้าเลือกได้อีกกี่ครั้ง เราก็ยังเลือกเธออยู่ดี",
    "ขอบคุณที่เป็นรอยยิ้มของเราในทุก ๆ วันนะ",
    "ไม่ต้องเป็นดาวที่สว่างที่สุดก็ได้ เพราะเธอเป็นดาวดวงโปรดของเรา ⭐",
    "อยากจับมือเธอไปดูพระจันทร์ด้วยกันทุกคืนเลย",
    "โลกใบนี้กว้างใหญ่มาก แต่เราดีใจที่ได้เจอเธอ",
    "เราอาจไม่ใช่คนที่สมบูรณ์แบบ แต่เราจะตั้งใจรักเธอนะ",
    "เธอไม่จำเป็นต้องเก่งทุกอย่าง แค่เป็นเธอเราก็รักแล้ว",
    "อยากให้เธอรู้ว่าเธอมีความหมายกับเรามากแค่ไหน",
    "ขอให้เราเป็นความสุขของกันและกันไปนาน ๆ นะ",
    "หนึ่งวันมี 24 ชั่วโมง แต่เราคิดถึงเธอได้ตลอดเลย",
    "รักเธอมากกว่าเมื่อวาน และจะรักมากขึ้นในวันพรุ่งนี้ ❤️"
];

const randomButton = document.getElementById("randomButton");
const randomMessage = document.getElementById("randomMessage");
const giftIcon = document.getElementById("giftIcon");

let previousMessage = -1;

randomButton.addEventListener("click", () => {
    let index;

    do {
        index = Math.floor(Math.random() * loveMessages.length);
    } while (index === previousMessage);

    previousMessage = index;

    giftIcon.textContent = "💝";

    randomMessage.textContent = loveMessages[index];

    randomMessage.animate(
        [
            { opacity: 0, transform: "translateY(12px)" },
            { opacity: 1, transform: "translateY(0)" }
        ],
        {
            duration: 500,
            easing: "ease"
        }
    );

    randomButton.textContent = "สุ่มข้อความอีกครั้ง 💗";
});


// 6. Love confession popup

const confessionButton =
    document.getElementById("confessionButton");

const lovePopup =
    document.getElementById("lovePopup");

const closePopup =
    document.getElementById("closePopup");

confessionButton.addEventListener("click", () => {
    lovePopup.classList.add("show");
});

const afterLoveMessage = document.getElementById("afterLoveMessage");

closePopup.addEventListener("click", () => {
    // First click reveals a second romantic message; the next click closes the popup.
    if (afterLoveMessage.hidden) {
        afterLoveMessage.hidden = false;
        closePopup.textContent = "กอดแน่น ๆ เลย 🫂";
        afterLoveMessage.animate(
            [
                { opacity: 0, transform: "translateY(10px)" },
                { opacity: 1, transform: "translateY(0)" }
            ],
            { duration: 500, easing: "ease-out" }
        );
    } else {
        lovePopup.classList.remove("show");
        afterLoveMessage.hidden = true;
        closePopup.textContent = "รักเธอเหมือนกัน 💗";
    }
});

lovePopup.addEventListener("click", event => {
    if (event.target === lovePopup) {
        lovePopup.classList.remove("show");
    }
});


// 7. Scroll reveal

const revealElements = document.querySelectorAll(
    ".section-label, .section h2, " +
    ".intro-card, .gallery-card, " +
    ".counter-card, .music-card, " +
    ".random-card, .confession-card, footer"
);

revealElements.forEach(element => {
    element.classList.add("reveal");
});

const revealObserver = new IntersectionObserver(
    entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
                revealObserver.unobserve(entry.target);
            }
        });
    },
    { threshold: 0.12 }
);

revealElements.forEach(element => {
    revealObserver.observe(element);
});


// 8. Floating hearts on click

document.addEventListener("click", event => {
    if (event.target.closest("button, a")) return;

    for (let i = 0; i < 4; i++) {
        const heart = document.createElement("span");

        heart.textContent = ["💗", "✨", "♡"][
            Math.floor(Math.random() * 3)
        ];

        heart.style.position = "fixed";
        heart.style.left = event.clientX + "px";
        heart.style.top = event.clientY + "px";
        heart.style.pointerEvents = "none";
        heart.style.zIndex = "9999";
        heart.style.fontSize = "18px";

        document.body.appendChild(heart);

        const x = (Math.random() - 0.5) * 120;
        const y = (Math.random() - 0.5) * 120;

        heart.animate(
            [
                {
                    transform: "translate(0,0) scale(.5)",
                    opacity: 1
                },
                {
                    transform: `translate(${x}px,${y}px) scale(1.5)`,
                    opacity: 0
                }
            ],
            {
                duration: 1000,
                easing: "ease-out"
            }
        );

        setTimeout(() => heart.remove(), 1100);
    }
});


// 9. Console greeting

console.log("Made with love for เฟย์ ♡");
console.log("You are my favorite star ✨");


// 10. Gallery lightbox: tap/click a photo to view it larger
const lightbox = document.createElement("div");
lightbox.className = "image-lightbox";
lightbox.setAttribute("role", "dialog");
lightbox.setAttribute("aria-modal", "true");
lightbox.setAttribute("aria-label", "ดูรูปภาพขนาดใหญ่");
lightbox.innerHTML = '<button type="button" aria-label="ปิดรูปภาพ">×</button><img alt="">';
document.body.appendChild(lightbox);
const lightboxImage = lightbox.querySelector("img");
const lightboxClose = lightbox.querySelector("button");

function openLightbox(photo) {
    lightboxImage.src = photo.currentSrc || photo.src;
    lightboxImage.alt = photo.alt || "รูปภาพ";
    lightbox.classList.add("show");
    document.body.style.overflow = "hidden";
    lightboxClose.focus();
}
function closeLightbox() {
    lightbox.classList.remove("show");
    document.body.style.overflow = "";
}
document.querySelectorAll(".gallery-image img").forEach(photo => {
    photo.addEventListener("click", () => openLightbox(photo));
    photo.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            openLightbox(photo);
        }
    });
});
lightboxClose.addEventListener("click", closeLightbox);
lightbox.addEventListener("click", event => {
    if (event.target === lightbox) closeLightbox();
});
document.addEventListener("keydown", event => {
    if (event.key === "Escape" && lightbox.classList.contains("show")) closeLightbox();
});
